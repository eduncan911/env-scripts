
/*!
 Copyright 2009 Sun Microsystems, Inc.
 */




#import "WBTabView.h"



@interface WBEditorTabView : WBTabView
{

}


@end


