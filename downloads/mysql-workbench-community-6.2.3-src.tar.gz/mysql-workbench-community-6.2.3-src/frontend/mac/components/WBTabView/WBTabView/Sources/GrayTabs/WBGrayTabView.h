
/*!
 Copyright 2009 Sun Microsystems, Inc.
 */



#import "WBTabView.h"



@interface WBGrayTabView : WBTabView
{
  NSImage *mPlaqueImage;
}
@end


@interface WBPaddedGrayTabView : WBGrayTabView
{
}
@end

@interface WBUnpaddedGrayTabView : WBGrayTabView
{
}
@end

