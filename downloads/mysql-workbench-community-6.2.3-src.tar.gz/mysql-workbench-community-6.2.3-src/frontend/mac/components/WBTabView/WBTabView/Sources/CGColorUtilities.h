
/*!
 Copyright 2009 Sun Microsystems, Inc.
 */



CGColorRef WB_CGColorCreateCalibratedRGB(CGFloat red, CGFloat green, CGFloat blue, CGFloat alpha);


