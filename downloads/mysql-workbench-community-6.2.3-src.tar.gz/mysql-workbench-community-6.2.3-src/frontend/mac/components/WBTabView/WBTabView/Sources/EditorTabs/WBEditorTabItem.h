
/*!
 Copyright 2009 Sun Microsystems, Inc.
 */



#import "WBTabItem.h"









@interface WBEditorTabItem : WBTabItem
{
}


+ (WBTabItem*) tabItemWithIdentifier: (id) identifier
                               label: (NSString*) label;


@end


