
/*!
 Copyright 2009 Sun Microsystems, Inc.
 */




#import "WBTabView.h"



@interface WBSchemaTabView : WBTabView
{

}

@end


