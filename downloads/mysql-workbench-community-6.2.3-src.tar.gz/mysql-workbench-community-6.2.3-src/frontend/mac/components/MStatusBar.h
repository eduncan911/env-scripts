//
//  MStatusBar.h
//  MySQLWorkbench
//
//  Created by Alfredo Kojima on 6/May/09.
//  Copyright 2009 Sun Microsystems Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MStatusBar : NSView {
  NSGradient *mGradient;
}

@end
