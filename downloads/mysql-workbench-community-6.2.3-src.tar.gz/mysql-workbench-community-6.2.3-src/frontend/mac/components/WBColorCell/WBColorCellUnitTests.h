/*!
 Copyright 2009 Sun Microsystems, Inc.
 */



#import <SenTestingKit/SenTestingKit.h>



@interface WBColorCellUnitTests : SenTestCase
{
  
}

@end


